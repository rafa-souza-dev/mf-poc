export * from './compiled-types/exposedTitle';
export { default } from './compiled-types/exposedTitle';