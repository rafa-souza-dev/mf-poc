/// <reference types="react" />
export default function ExposedTitle(): import("react").JSX.Element;
